To enable rotation of images, place the .jpg background image files and optionally a settings .xml files for a background image in this folder.
If there is no settings file for an image, the default settings file (TheaterMode.Settings.xml) in the Plugins folder will be used.
You can set the rotation period (seconds) in the default settings file:  <settings rotationPeriod="300" />

For example, you could add the 3 screen saver images to this folder, where "Relax" has a specific settings file:
Relax.jpg
Relax.xml
Second Image.jpg
Rainbow.jpg
